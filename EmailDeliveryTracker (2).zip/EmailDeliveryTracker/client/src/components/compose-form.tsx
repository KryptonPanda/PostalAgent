import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { postalApi } from "@/lib/postal-api";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Send } from "lucide-react";

const sendEmailSchema = z.object({
  fromEmail: z.string().email("Please enter a valid email address"),
  toEmail: z.string().email("Please enter a valid recipient email"),
  subject: z.string().min(1, "Subject is required"),
  content: z.string().min(1, "Content is required"),
  templateId: z.string().optional(),
  trackDelivery: z.boolean().default(true),
});

type SendEmailForm = z.infer<typeof sendEmailSchema>;

export default function ComposeForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<SendEmailForm>({
    resolver: zodResolver(sendEmailSchema),
    defaultValues: {
      fromEmail: "hello@bmh3.clfaceverifiy.com",
      toEmail: "",
      subject: "",
      content: "",
      trackDelivery: true,
    },
  });

  const { data: templates } = useQuery({
    queryKey: ["/api/templates"],
    queryFn: () => postalApi.getEmailTemplates(),
  });

  const sendEmailMutation = useMutation({
    mutationFn: (data: SendEmailForm) => {
      const payload = {
        fromEmail: data.fromEmail,
        toEmail: data.toEmail,
        subject: data.subject,
        content: data.content,
        trackDelivery: data.trackDelivery,
        templateId: data.templateId ? parseInt(data.templateId) : undefined,
      };
      return postalApi.sendEmail(payload);
    },
    onSuccess: (result) => {
      toast({
        title: "Email sent successfully!",
        description: `Message ID: ${result.messageId}`,
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to send email",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SendEmailForm) => {
    sendEmailMutation.mutate(data);
  };

  const handleTemplateSelect = (templateId: string) => {
    if (!templateId || !templates) return;
    
    const template = templates.find(t => t.id.toString() === templateId);
    if (template) {
      form.setValue("subject", template.subject);
      form.setValue("content", template.content);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-lg font-medium text-gray-900 flex items-center">
          <Send className="mr-2 h-5 w-5" />
          Compose Email
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="fromEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>From</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="toEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>To</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" placeholder="recipient@example.com" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {templates && templates.length > 0 && (
              <FormField
                control={form.control}
                name="templateId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Template (Optional)</FormLabel>
                    <Select 
                      value={field.value} 
                      onValueChange={(value) => {
                        field.onChange(value);
                        handleTemplateSelect(value);
                      }}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a template" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="">No template</SelectItem>
                        {templates.map((template) => (
                          <SelectItem key={template.id} value={template.id.toString()}>
                            {template.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="subject"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Subject</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Enter email subject" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      rows={8} 
                      placeholder="Enter your email content here..." 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex items-center justify-between">
              <FormField
                control={form.control}
                name="trackDelivery"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>
                        Track delivery status
                      </FormLabel>
                    </div>
                  </FormItem>
                )}
              />

              <div className="flex space-x-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => form.reset()}
                  disabled={sendEmailMutation.isPending}
                >
                  Clear
                </Button>
                <Button 
                  type="submit" 
                  disabled={sendEmailMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {sendEmailMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Send Email
                    </>
                  )}
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
