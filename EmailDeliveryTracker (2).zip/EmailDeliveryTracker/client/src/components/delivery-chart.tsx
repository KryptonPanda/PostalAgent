import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { postalApi } from "@/lib/postal-api";

export default function DeliveryChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);

  const { data: trends, isLoading } = useQuery({
    queryKey: ["/api/analytics/trends"],
    queryFn: () => postalApi.getDeliveryTrends(7),
  });

  useEffect(() => {
    if (!trends || !canvasRef.current || isLoading) return;

    const loadChart = async () => {
      // Dynamically import Chart.js
      const { Chart, registerables } = await import("chart.js");
      Chart.register(...registerables);

      const ctx = canvasRef.current!.getContext("2d")!;

      // Destroy existing chart
      if (chartRef.current) {
        chartRef.current.destroy();
      }

      // Prepare data
      const labels = trends.map((trend) => {
        const date = new Date(trend.date);
        return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
      });

      const deliveredData = trends.map((trend) => trend.delivered || 0);
      const bouncedData = trends.map((trend) => trend.bounced || 0);

      chartRef.current = new Chart(ctx, {
        type: "line",
        data: {
          labels,
          datasets: [
            {
              label: "Delivered",
              data: deliveredData,
              borderColor: "#10B981",
              backgroundColor: "rgba(16, 185, 129, 0.1)",
              tension: 0.4,
              fill: true,
            },
            {
              label: "Bounced",
              data: bouncedData,
              borderColor: "#EF4444",
              backgroundColor: "rgba(239, 68, 68, 0.1)",
              tension: 0.4,
              fill: true,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: "top",
            },
          },
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    };

    loadChart();

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [trends, isLoading]);

  return (
    <Card className="bg-white shadow">
      <CardHeader>
        <CardTitle className="text-lg font-medium text-gray-900">
          Delivery Trends
        </CardTitle>
        <p className="text-sm text-gray-500">Email delivery performance over time</p>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-gray-500">Loading chart...</div>
            </div>
          ) : (
            <canvas ref={canvasRef} className="w-full h-full" />
          )}
        </div>
      </CardContent>
    </Card>
  );
}
