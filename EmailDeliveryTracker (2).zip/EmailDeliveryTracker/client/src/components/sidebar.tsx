import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Edit, 
  History, 
  TrendingUp, 
  Users, 
  FileText, 
  Settings,
  Mail,
  Circle
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: BarChart3, label: "Dashboard" },
    { path: "/compose", icon: Edit, label: "Compose Email" },
    { path: "/history", icon: History, label: "Email History" },
    { path: "/analytics", icon: TrendingUp, label: "Analytics" },
    { path: "/recipients", icon: Users, label: "Recipients" },
    { path: "/templates", icon: FileText, label: "Templates" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  const isActive = (path: string) => {
    if (path === "/") {
      return location === "/";
    }
    return location.startsWith(path);
  };

  return (
    <div className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64">
        <div className="flex flex-col flex-grow bg-white border-r border-gray-200 pt-5 pb-4 overflow-y-auto">
          {/* Header */}
          <div className="flex items-center flex-shrink-0 px-4">
            <div className="flex items-center">
              <div className="bg-blue-600 rounded-lg p-2">
                <Mail className="text-white text-xl h-6 w-6" />
              </div>
              <div className="ml-3">
                <h1 className="text-xl font-semibold text-gray-900">Postal Dashboard</h1>
                <p className="text-sm text-gray-500">postal3.clfaceverifiy.com</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="mt-5 flex-grow flex flex-col">
            <nav className="flex-1 px-2 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.path);
                
                return (
                  <Link
                    key={item.path}
                    href={item.path}
                    className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ${
                      active
                        ? "bg-blue-600 text-white"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                    }`}
                  >
                    <Icon className="mr-3 h-5 w-5" />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* Footer */}
          <div className="flex-shrink-0 flex border-t border-gray-200 p-4">
            <div className="flex items-center">
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-700">API Status</p>
                <div className="flex items-center mt-1">
                  <Circle className="h-2 w-2 bg-green-500 rounded-full fill-current text-green-500" />
                  <p className="ml-2 text-xs text-gray-500">Connected</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
