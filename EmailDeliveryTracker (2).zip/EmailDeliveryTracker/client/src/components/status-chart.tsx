import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { postalApi } from "@/lib/postal-api";

export default function StatusChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);

  const { data: distribution, isLoading } = useQuery({
    queryKey: ["/api/analytics/status-distribution"],
    queryFn: () => postalApi.getStatusDistribution(),
  });

  useEffect(() => {
    if (!distribution || !canvasRef.current || isLoading) return;

    const loadChart = async () => {
      // Dynamically import Chart.js
      const { Chart, registerables } = await import("chart.js");
      Chart.register(...registerables);

      const ctx = canvasRef.current!.getContext("2d")!;

      // Destroy existing chart
      if (chartRef.current) {
        chartRef.current.destroy();
      }

      // Prepare data
      const statusColors: Record<string, string> = {
        delivered: "#10B981",
        bounced: "#F59E0B",
        spam: "#8B5CF6",
        failed: "#EF4444",
        pending: "#6B7280",
        sent: "#3B82F6",
      };

      const labels = distribution.map((item) => 
        item.status.charAt(0).toUpperCase() + item.status.slice(1)
      );
      const data = distribution.map((item) => item.count);
      const colors = distribution.map((item) => statusColors[item.status] || "#6B7280");

      chartRef.current = new Chart(ctx, {
        type: "doughnut",
        data: {
          labels,
          datasets: [
            {
              data,
              backgroundColor: colors,
              borderWidth: 2,
              borderColor: "#ffffff",
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: "bottom",
            },
          },
        },
      });
    };

    loadChart();

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [distribution, isLoading]);

  return (
    <Card className="bg-white shadow">
      <CardHeader>
        <CardTitle className="text-lg font-medium text-gray-900">
          Status Distribution
        </CardTitle>
        <p className="text-sm text-gray-500">Current email status breakdown</p>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-gray-500">Loading chart...</div>
            </div>
          ) : (
            <canvas ref={canvasRef} className="w-full h-full" />
          )}
        </div>
      </CardContent>
    </Card>
  );
}
