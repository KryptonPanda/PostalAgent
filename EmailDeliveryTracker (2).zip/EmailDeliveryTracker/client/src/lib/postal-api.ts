import { apiRequest } from "./queryClient";

export interface DashboardStats {
  totalSent: number;
  totalDelivered: number;
  totalBounced: number;
  totalSpam: number;
  deliveryRate: number;
  bounceRate: number;
  spamRate: number;
}

export interface DeliveryTrend {
  date: string;
  delivered: number;
  bounced: number;
  spam: number;
  total: number;
}

export interface StatusDistribution {
  status: string;
  count: number;
}

export interface Email {
  id: number;
  postalMessageId?: string;
  fromEmail: string;
  toEmail: string;
  subject: string;
  content: string;
  status: string;
  bounceType?: string;
  deliveredAt?: string;
  openedAt?: string;
  clickedAt?: string;
  unsubscribedAt?: string;
  spamReportedAt?: string;
  errorMessage?: string;
  recipientId?: number;
  templateId?: number;
  metadata?: any;
  createdAt: string;
  updatedAt: string;
}

export interface Recipient {
  id: number;
  email: string;
  name?: string;
  isActive: boolean;
  createdAt: string;
}

export interface EmailTemplate {
  id: number;
  name: string;
  subject: string;
  content: string;
  isActive: boolean;
  createdAt: string;
}

export interface SendEmailRequest {
  fromEmail: string;
  toEmail: string;
  subject: string;
  content: string;
  recipientId?: number;
  templateId?: number;
  trackDelivery?: boolean;
}

export const postalApi = {
  // Dashboard
  async getDashboardStats(): Promise<DashboardStats> {
    const response = await apiRequest("GET", "/api/dashboard/stats");
    return response.json();
  },

  // Analytics
  async getDeliveryTrends(days: number = 7): Promise<DeliveryTrend[]> {
    const response = await apiRequest("GET", `/api/analytics/trends?days=${days}`);
    return response.json();
  },

  async getStatusDistribution(): Promise<StatusDistribution[]> {
    const response = await apiRequest("GET", "/api/analytics/status-distribution");
    return response.json();
  },

  // Emails
  async sendEmail(emailData: SendEmailRequest): Promise<{ success: boolean; messageId: string; emailId: number }> {
    const response = await apiRequest("POST", "/api/emails/send", emailData);
    return response.json();
  },

  async getEmails(limit: number = 50): Promise<Email[]> {
    const response = await apiRequest("GET", `/api/emails?limit=${limit}`);
    return response.json();
  },

  async getEmail(id: number): Promise<Email> {
    const response = await apiRequest("GET", `/api/emails/${id}`);
    return response.json();
  },

  async checkEmailStatus(id: number): Promise<any> {
    const response = await apiRequest("POST", `/api/emails/${id}/check-status`);
    return response.json();
  },

  // Recipients
  async getRecipients(): Promise<Recipient[]> {
    const response = await apiRequest("GET", "/api/recipients");
    return response.json();
  },

  async createRecipient(data: { email: string; name?: string }): Promise<Recipient> {
    const response = await apiRequest("POST", "/api/recipients", data);
    return response.json();
  },

  // Templates
  async getEmailTemplates(): Promise<EmailTemplate[]> {
    const response = await apiRequest("GET", "/api/templates");
    return response.json();
  },

  async createEmailTemplate(data: { name: string; subject: string; content: string }): Promise<EmailTemplate> {
    const response = await apiRequest("POST", "/api/templates", data);
    return response.json();
  },
};
