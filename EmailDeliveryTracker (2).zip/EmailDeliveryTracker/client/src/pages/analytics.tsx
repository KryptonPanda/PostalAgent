import { Search, Plus, Download } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import DeliveryChart from "@/components/delivery-chart";
import StatusChart from "@/components/status-chart";
import StatsCard from "@/components/stats-card";
import { useQuery } from "@tanstack/react-query";
import { postalApi } from "@/lib/postal-api";
import { 
  Send, 
  CheckCircle, 
  AlertTriangle, 
  Shield,
  TrendingUp,
  TrendingDown,
  Minus
} from "lucide-react";

export default function Analytics() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: () => postalApi.getDashboardStats(),
  });

  return (
    <>
      {/* Top Navigation */}
      <div className="relative z-10 flex-shrink-0 flex h-16 bg-white shadow">
        <div className="flex-1 px-4 flex justify-between">
          <div className="flex-1 flex">
            <div className="w-full flex md:ml-0">
              <div className="relative w-full text-gray-400 focus-within:text-gray-600">
                <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none pl-3">
                  <Search className="h-5 w-5" />
                </div>
                <Input 
                  className="block w-full h-full pl-10 pr-3 py-2 border-transparent text-gray-900 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-0 focus:border-transparent"
                  placeholder="Search analytics..." 
                  type="search"
                />
              </div>
            </div>
          </div>
          <div className="ml-4 flex items-center md:ml-6 space-x-2">
            <Button variant="outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Export Report
            </Button>
            <Link href="/compose">
              <Button className="bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">
                <Plus className="mr-2 h-4 w-4" />
                Compose
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Analytics Content */}
      <main className="flex-1 relative overflow-y-auto focus:outline-none">
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Analytics Header */}
            <div className="md:flex md:items-center md:justify-between mb-8">
              <div className="flex-1 min-w-0">
                <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                  Email Analytics
                </h2>
                <p className="mt-1 text-sm text-gray-500">
                  Detailed insights into your email performance and delivery metrics
                </p>
              </div>
              <div className="mt-4 flex md:mt-0 md:ml-4 space-x-2">
                <Select defaultValue="7d">
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="24h">Last 24 Hours</SelectItem>
                    <SelectItem value="7d">Last 7 Days</SelectItem>
                    <SelectItem value="30d">Last 30 Days</SelectItem>
                    <SelectItem value="90d">Last 90 Days</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Key Metrics */}
            <div className="mb-8">
              {isLoading ? (
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="bg-white overflow-hidden shadow rounded-lg animate-pulse">
                      <div className="p-5">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-gray-200 rounded-md"></div>
                          <div className="ml-5 w-0 flex-1">
                            <div className="h-4 bg-gray-200 rounded w-20 mb-2"></div>
                            <div className="h-6 bg-gray-200 rounded w-16"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : stats ? (
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                  <StatsCard
                    title="Total Sent"
                    value={stats.totalSent.toLocaleString()}
                    icon={Send}
                    iconBgColor="bg-blue-600"
                    change="+12%"
                    changeType="positive"
                  />
                  <StatsCard
                    title="Delivered"
                    value={stats.totalDelivered.toLocaleString()}
                    icon={CheckCircle}
                    iconBgColor="bg-green-500"
                    change="+8%"
                    changeType="positive"
                  />
                  <StatsCard
                    title="Bounced"
                    value={stats.totalBounced.toLocaleString()}
                    icon={AlertTriangle}
                    iconBgColor="bg-red-500"
                    change="+15%"
                    changeType="negative"
                  />
                  <StatsCard
                    title="Spam Reports"
                    value={stats.totalSpam.toLocaleString()}
                    icon={Shield}
                    iconBgColor="bg-purple-500"
                    change="-2%"
                    changeType="positive"
                  />
                </div>
              ) : null}
            </div>

            {/* Performance Metrics */}
            <div className="mb-8">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="animate-pulse">
                          <div className="h-20 bg-gray-200 rounded"></div>
                        </div>
                      ))}
                    </div>
                  ) : stats ? (
                    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
                      <div className="text-center p-6 border rounded-lg">
                        <div className="text-3xl font-bold text-green-600 mb-2">
                          {stats.deliveryRate}%
                        </div>
                        <div className="text-sm text-gray-600">Delivery Rate</div>
                        <div className="flex items-center justify-center mt-2 text-green-600">
                          <TrendingUp className="h-4 w-4 mr-1" />
                          <span className="text-xs">+2.1% from last week</span>
                        </div>
                      </div>
                      
                      <div className="text-center p-6 border rounded-lg">
                        <div className="text-3xl font-bold text-red-600 mb-2">
                          {stats.bounceRate}%
                        </div>
                        <div className="text-sm text-gray-600">Bounce Rate</div>
                        <div className="flex items-center justify-center mt-2 text-red-600">
                          <TrendingUp className="h-4 w-4 mr-1" />
                          <span className="text-xs">+0.3% from last week</span>
                        </div>
                      </div>
                      
                      <div className="text-center p-6 border rounded-lg">
                        <div className="text-3xl font-bold text-purple-600 mb-2">
                          {stats.spamRate}%
                        </div>
                        <div className="text-sm text-gray-600">Spam Rate</div>
                        <div className="flex items-center justify-center mt-2 text-green-600">
                          <TrendingDown className="h-4 w-4 mr-1" />
                          <span className="text-xs">-0.1% from last week</span>
                        </div>
                      </div>
                    </div>
                  ) : null}
                </CardContent>
              </Card>
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2 mb-8">
              <DeliveryChart />
              <StatusChart />
            </div>

            {/* Additional Analytics */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Bounce Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Soft Bounces</span>
                      <span className="font-medium">85%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '85%' }}></div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Hard Bounces</span>
                      <span className="font-medium">15%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-red-500 h-2 rounded-full" style={{ width: '15%' }}></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Top Bounce Reasons</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center py-2">
                      <span className="text-sm text-gray-600">Mailbox Full</span>
                      <span className="text-sm font-medium">45%</span>
                    </div>
                    <div className="flex justify-between items-center py-2">
                      <span className="text-sm text-gray-600">Invalid Email</span>
                      <span className="text-sm font-medium">30%</span>
                    </div>
                    <div className="flex justify-between items-center py-2">
                      <span className="text-sm text-gray-600">Server Temporarily Down</span>
                      <span className="text-sm font-medium">15%</span>
                    </div>
                    <div className="flex justify-between items-center py-2">
                      <span className="text-sm text-gray-600">Other</span>
                      <span className="text-sm font-medium">10%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
