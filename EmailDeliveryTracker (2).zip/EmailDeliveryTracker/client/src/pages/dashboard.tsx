import { useQuery } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import StatsCard from "@/components/stats-card";
import DeliveryChart from "@/components/delivery-chart";
import StatusChart from "@/components/status-chart";
import RecentActivity from "@/components/recent-activity";
import { postalApi } from "@/lib/postal-api";
import { 
  Send, 
  CheckCircle, 
  AlertTriangle, 
  Shield
} from "lucide-react";

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: () => postalApi.getDashboardStats(),
  });

  return (
    <>
      {/* Top Navigation */}
      <div className="relative z-10 flex-shrink-0 flex h-16 bg-white shadow">
        <div className="flex-1 px-4 flex justify-between">
          <div className="flex-1 flex">
            <div className="w-full flex md:ml-0">
              <div className="relative w-full text-gray-400 focus-within:text-gray-600">
                <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none pl-3">
                  <Search className="h-5 w-5" />
                </div>
                <Input 
                  className="block w-full h-full pl-10 pr-3 py-2 border-transparent text-gray-900 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-0 focus:border-transparent"
                  placeholder="Search emails..." 
                  type="search"
                />
              </div>
            </div>
          </div>
          <div className="ml-4 flex items-center md:ml-6">
            <Link href="/compose">
              <Button className="bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">
                <Plus className="mr-2 h-4 w-4" />
                Compose
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Dashboard Content */}
      <main className="flex-1 relative overflow-y-auto focus:outline-none">
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Dashboard Header */}
            <div className="md:flex md:items-center md:justify-between">
              <div className="flex-1 min-w-0">
                <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                  Email Deliverability Dashboard
                </h2>
                <p className="mt-1 text-sm text-gray-500">
                  Real-time monitoring and analytics for your email campaigns
                </p>
              </div>
              <div className="mt-4 flex md:mt-0 md:ml-4">
                <Select defaultValue="24h">
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="24h">Last 24 Hours</SelectItem>
                    <SelectItem value="7d">Last 7 Days</SelectItem>
                    <SelectItem value="30d">Last 30 Days</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Statistics Cards */}
            <div className="mt-8">
              {isLoading ? (
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="bg-white overflow-hidden shadow rounded-lg animate-pulse">
                      <div className="p-5">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-gray-200 rounded-md"></div>
                          <div className="ml-5 w-0 flex-1">
                            <div className="h-4 bg-gray-200 rounded w-20 mb-2"></div>
                            <div className="h-6 bg-gray-200 rounded w-16"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : stats ? (
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                  <StatsCard
                    title="Total Sent"
                    value={stats.totalSent.toLocaleString()}
                    icon={Send}
                    iconBgColor="bg-blue-600"
                    change="+12%"
                    changeType="positive"
                  />
                  <StatsCard
                    title="Delivery Rate"
                    value={`${stats.deliveryRate}%`}
                    icon={CheckCircle}
                    iconBgColor="bg-green-500"
                    change="+2.1%"
                    changeType="positive"
                  />
                  <StatsCard
                    title="Bounce Rate"
                    value={`${stats.bounceRate}%`}
                    icon={AlertTriangle}
                    iconBgColor="bg-red-500"
                    change="+0.3%"
                    changeType="negative"
                  />
                  <StatsCard
                    title="Spam Rate"
                    value={`${stats.spamRate}%`}
                    icon={Shield}
                    iconBgColor="bg-yellow-500"
                    change="-0.1%"
                    changeType="positive"
                  />
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">Unable to load statistics</p>
                </div>
              )}
            </div>

            {/* Charts Section */}
            <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
              <DeliveryChart />
              <StatusChart />
            </div>

            {/* Recent Activity */}
            <div className="mt-8">
              <RecentActivity />
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
