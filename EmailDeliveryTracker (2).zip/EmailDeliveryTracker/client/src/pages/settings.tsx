import { useState } from "react";
import { Search, Plus, Settings as SettingsIcon, Server, Key, Globe, CheckCircle, XCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";

export default function Settings() {
  const [trackingEnabled, setTrackingEnabled] = useState(true);
  const [webhooksEnabled, setWebhooksEnabled] = useState(true);
  const [retryFailures, setRetryFailures] = useState(true);

  // Mock API connection status - in a real app this would be fetched
  const apiStatus = {
    connected: true,
    hostname: "postal3.clfaceverifiy.com",
    domain: "bmh3.clfaceverifiy.com", 
    lastChecked: new Date().toISOString(),
    responseTime: "142ms"
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <>
      {/* Top Navigation */}
      <div className="relative z-10 flex-shrink-0 flex h-16 bg-white shadow">
        <div className="flex-1 px-4 flex justify-between">
          <div className="flex-1 flex">
            <div className="w-full flex md:ml-0">
              <div className="relative w-full text-gray-400 focus-within:text-gray-600">
                <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none pl-3">
                  <Search className="h-5 w-5" />
                </div>
                <Input 
                  className="block w-full h-full pl-10 pr-3 py-2 border-transparent text-gray-900 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-0 focus:border-transparent"
                  placeholder="Search settings..." 
                  type="search"
                />
              </div>
            </div>
          </div>
          <div className="ml-4 flex items-center md:ml-6">
            <Link href="/compose">
              <Button className="bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">
                <Plus className="mr-2 h-4 w-4" />
                Compose
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Settings Content */}
      <main className="flex-1 relative overflow-y-auto focus:outline-none">
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            <div className="mb-8">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                Settings
              </h2>
              <p className="mt-1 text-sm text-gray-500">
                Configure your Postal email service and application preferences
              </p>
            </div>

            <div className="space-y-6">
              {/* API Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Server className="mr-2 h-5 w-5" />
                    Postal API Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Connection Status */}
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      {apiStatus.connected ? (
                        <CheckCircle className="h-6 w-6 text-green-500" />
                      ) : (
                        <XCircle className="h-6 w-6 text-red-500" />
                      )}
                      <div>
                        <h3 className="font-medium text-gray-900">
                          {apiStatus.connected ? "Connected" : "Disconnected"}
                        </h3>
                        <p className="text-sm text-gray-500">
                          Last checked: {formatDate(apiStatus.lastChecked)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant={apiStatus.connected ? "default" : "destructive"}>
                        {apiStatus.connected ? "Online" : "Offline"}
                      </Badge>
                      {apiStatus.connected && (
                        <p className="text-xs text-gray-500 mt-1">
                          Response time: {apiStatus.responseTime}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Server Details */}
                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Hostname</Label>
                      <div className="mt-1 flex items-center space-x-2">
                        <Globe className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-900 font-mono">
                          {apiStatus.hostname}
                        </span>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Domain</Label>
                      <div className="mt-1 flex items-center space-x-2">
                        <Globe className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-900 font-mono">
                          {apiStatus.domain}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* API Key */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700">API Key</Label>
                    <div className="mt-1 flex items-center space-x-2">
                      <Key className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-900 font-mono">
                        KFBcjBpjIZQbUq3AMyfhDw0c
                      </span>
                      <Badge variant="secondary">Active</Badge>
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      API key is configured and working properly
                    </p>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <Button variant="outline">
                      Test Connection
                    </Button>
                    <Button variant="outline">
                      Refresh Status
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Email Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <SettingsIcon className="mr-2 h-5 w-5" />
                    Email Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-sm font-medium">Delivery Tracking</Label>
                      <p className="text-xs text-gray-500">
                        Track email delivery status and engagement metrics
                      </p>
                    </div>
                    <Switch
                      checked={trackingEnabled}
                      onCheckedChange={setTrackingEnabled}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-sm font-medium">Webhook Notifications</Label>
                      <p className="text-xs text-gray-500">
                        Receive real-time delivery status updates via webhooks
                      </p>
                    </div>
                    <Switch
                      checked={webhooksEnabled}
                      onCheckedChange={setWebhooksEnabled}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-sm font-medium">Retry Failed Deliveries</Label>
                      <p className="text-xs text-gray-500">
                        Automatically retry sending emails that fail due to temporary issues
                      </p>
                    </div>
                    <Switch
                      checked={retryFailures}
                      onCheckedChange={setRetryFailures}
                    />
                  </div>

                  <Separator />

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="text-lg font-semibold text-gray-900">5</div>
                      <div className="text-xs text-gray-500">Max Retry Attempts</div>
                    </div>
                    
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="text-lg font-semibold text-gray-900">24h</div>
                      <div className="text-xs text-gray-500">Retry Window</div>
                    </div>
                    
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="text-lg font-semibold text-gray-900">30d</div>
                      <div className="text-xs text-gray-500">Log Retention</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Webhook Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle>Postal Webhook Configuration</CardTitle>
                  <p className="text-sm text-gray-600">
                    Configure your Postal server to send delivery events to this dashboard
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Webhook URL */}
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <Label className="text-sm font-medium text-gray-900 mb-2 block">
                      Webhook Endpoint URL
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        value={`${window.location.origin}/api/webhooks/postal`}
                        readOnly
                        className="font-mono text-sm bg-white"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigator.clipboard.writeText(`${window.location.origin}/api/webhooks/postal`)}
                      >
                        Copy
                      </Button>
                    </div>
                    <p className="mt-2 text-xs text-blue-600">
                      ✓ Use this exact URL in your Postal server webhook configuration
                    </p>
                  </div>

                  {/* Configuration Steps */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-3">Setup Instructions</h4>
                    <div className="space-y-3">
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center font-medium">
                          1
                        </div>
                        <div>
                          <p className="text-sm text-gray-900">Login to Postal Admin Panel</p>
                          <p className="text-xs text-gray-500">Access your Postal server at postal3.clfaceverifiy.com</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center font-medium">
                          2
                        </div>
                        <div>
                          <p className="text-sm text-gray-900">Navigate to Webhook Settings</p>
                          <p className="text-xs text-gray-500">Usually found under "Server Settings" → "Webhooks" or "API Configuration"</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center font-medium">
                          3
                        </div>
                        <div>
                          <p className="text-sm text-gray-900">Add New Webhook</p>
                          <p className="text-xs text-gray-500">Create a new webhook endpoint with the URL above</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center font-medium">
                          4
                        </div>
                        <div>
                          <p className="text-sm text-gray-900">Configure Event Types</p>
                          <p className="text-xs text-gray-500">Select the events listed below to track delivery status</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Required Settings */}
                  <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                    <div className="p-4 border rounded-lg">
                      <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Required Event Types
                      </h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">MessageSent</span>
                          <Badge variant="secondary">Essential</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">MessageDelivered</span>
                          <Badge variant="secondary">Essential</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">MessageBounced</span>
                          <Badge variant="secondary">Essential</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">MessageFailed</span>
                          <Badge variant="secondary">Essential</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">MessageLoadComplete</span>
                          <Badge variant="outline">Optional</Badge>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                        <Settings className="h-4 w-4 text-blue-500 mr-2" />
                        Webhook Settings
                      </h4>
                      <div className="space-y-3">
                        <div>
                          <Label className="text-xs text-gray-500">Request Method</Label>
                          <p className="text-sm font-mono">POST</p>
                        </div>
                        <div>
                          <Label className="text-xs text-gray-500">Content Type</Label>
                          <p className="text-sm font-mono">application/json</p>
                        </div>
                        <div>
                          <Label className="text-xs text-gray-500">Timeout</Label>
                          <p className="text-sm font-mono">30 seconds</p>
                        </div>
                        <div>
                          <Label className="text-xs text-gray-500">Retry Policy</Label>
                          <p className="text-sm font-mono">3 attempts</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Expected Payload Format */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-3">Expected Payload Format</h4>
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <pre className="text-xs text-gray-600 overflow-x-auto">
{`{
  "event": "MessageDelivered",
  "payload": {
    "message_id": "abc123",
    "status": "delivered",
    "timestamp": "2025-05-26T20:30:00Z",
    "bounce_type": null,
    "details": "Message delivered successfully"
  }
}`}
                      </pre>
                    </div>
                  </div>

                  {/* Status Indicators */}
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                        <span className="text-sm text-gray-600">Webhook Status: Not Configured</span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Test Webhook
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* System Information */}
              <Card>
                <CardHeader>
                  <CardTitle>System Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">v1.0.0</div>
                      <div className="text-xs text-gray-500 mt-1">Application Version</div>
                    </div>
                    
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-green-600">99.9%</div>
                      <div className="text-xs text-gray-500 mt-1">Uptime</div>
                    </div>
                    
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">PostgreSQL</div>
                      <div className="text-xs text-gray-500 mt-1">Database</div>
                    </div>
                    
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">Node.js</div>
                      <div className="text-xs text-gray-500 mt-1">Runtime</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
