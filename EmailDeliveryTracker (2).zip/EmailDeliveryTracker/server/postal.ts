interface PostalApiResponse {
  status: string;
  data?: any;
  message?: string;
}

interface PostalMessage {
  id: string;
  token: string;
}

interface SendEmailRequest {
  to: string[];
  from: string;
  subject: string;
  plain_body?: string;
  html_body?: string;
  reply_to?: string;
  headers?: Record<string, string>;
  attachments?: any[];
}

interface WebhookEvent {
  event: string;
  payload: {
    message_id: string;
    status: string;
    details?: string;
    bounce_type?: string;
    timestamp: string;
  };
}

export class PostalApi {
  private hostname: string;
  private apiKey: string;

  constructor() {
    this.hostname = process.env.POSTAL_HOSTNAME || "postal3.clfaceverifiy.com";
    this.apiKey = process.env.POSTAL_API_KEY || "KFBcjBpjIZQbUq3AMyfhDw0c";
  }

  private async makeRequest(endpoint: string, method: string = 'GET', data?: any): Promise<PostalApiResponse> {
    const url = `https://${this.hostname}/api/v1${endpoint}`;
    
    try {
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'X-Server-API-Key': this.apiKey,
        },
        body: data ? JSON.stringify(data) : undefined,
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(`Postal API error: ${result.message || response.statusText}`);
      }

      return result;
    } catch (error) {
      console.error('Postal API request failed:', error);
      throw error;
    }
  }

  async sendEmail(emailData: SendEmailRequest): Promise<PostalMessage> {
    const response = await this.makeRequest('/send/message', 'POST', emailData);
    
    if (response.status !== 'success') {
      throw new Error(`Failed to send email: ${response.message}`);
    }

    return response.data as PostalMessage;
  }

  async getMessageDetails(messageId: string): Promise<any> {
    const response = await this.makeRequest(`/messages/${messageId}`);
    
    if (response.status !== 'success') {
      throw new Error(`Failed to get message details: ${response.message}`);
    }

    return response.data;
  }

  async getMessageDeliveries(messageId: string): Promise<any> {
    const response = await this.makeRequest(`/messages/${messageId}/deliveries`);
    
    if (response.status !== 'success') {
      throw new Error(`Failed to get message deliveries: ${response.message}`);
    }

    return response.data;
  }

  async getStats(): Promise<any> {
    const response = await this.makeRequest('/stats');
    
    if (response.status !== 'success') {
      throw new Error(`Failed to get stats: ${response.message}`);
    }

    return response.data;
  }

  processWebhookEvent(event: WebhookEvent): {
    messageId: string;
    status: string;
    bounceType?: string;
    timestamp: Date;
  } {
    return {
      messageId: event.payload.message_id,
      status: this.mapPostalStatusToInternalStatus(event.payload.status),
      bounceType: event.payload.bounce_type,
      timestamp: new Date(event.payload.timestamp),
    };
  }

  private mapPostalStatusToInternalStatus(postalStatus: string): string {
    const statusMap: Record<string, string> = {
      'sent': 'sent',
      'delivered': 'delivered',
      'bounced': 'bounced',
      'spam': 'spam',
      'failed': 'failed',
      'held': 'pending',
    };

    return statusMap[postalStatus] || 'pending';
  }
}

export const postalApi = new PostalApi();
