import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { postalApi } from "./postal";
import { sendEmailSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  // Delivery trends
  app.get("/api/analytics/trends", async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 7;
      const trends = await storage.getDeliveryTrends(days);
      res.json(trends);
    } catch (error) {
      console.error("Error fetching delivery trends:", error);
      res.status(500).json({ error: "Failed to fetch delivery trends" });
    }
  });

  // Status distribution
  app.get("/api/analytics/status-distribution", async (req, res) => {
    try {
      const distribution = await storage.getStatusDistribution();
      res.json(distribution);
    } catch (error) {
      console.error("Error fetching status distribution:", error);
      res.status(500).json({ error: "Failed to fetch status distribution" });
    }
  });

  // Send email
  app.post("/api/emails/send", async (req, res) => {
    try {
      const emailData = sendEmailSchema.parse(req.body);
      
      // Create or get recipient
      let recipient = await storage.getRecipientByEmail(emailData.toEmail);
      if (!recipient) {
        recipient = await storage.createRecipient({
          email: emailData.toEmail,
          name: emailData.toEmail.split('@')[0],
        });
      }

      // Send via Postal API
      const postalResponse = await postalApi.sendEmail({
        to: [emailData.toEmail],
        from: emailData.fromEmail,
        subject: emailData.subject,
        html_body: emailData.content,
        headers: {
          'X-Track-Delivery': emailData.trackDelivery.toString(),
        },
      });

      // Save email record
      const email = await storage.createEmail({
        postalMessageId: postalResponse.id,
        fromEmail: emailData.fromEmail,
        toEmail: emailData.toEmail,
        subject: emailData.subject,
        content: emailData.content,
        status: 'sent',
        recipientId: recipient.id,
        templateId: emailData.templateId,
        metadata: { token: postalResponse.token },
      });

      res.json({
        success: true,
        messageId: postalResponse.id,
        emailId: email.id,
      });
    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ 
        error: "Failed to send email",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get emails
  app.get("/api/emails", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const emails = await storage.getEmails(limit);
      res.json(emails);
    } catch (error) {
      console.error("Error fetching emails:", error);
      res.status(500).json({ error: "Failed to fetch emails" });
    }
  });

  // Get email by ID
  app.get("/api/emails/:id", async (req, res) => {
    try {
      const emailId = parseInt(req.params.id);
      const email = await storage.getEmail(emailId);
      
      if (!email) {
        return res.status(404).json({ error: "Email not found" });
      }

      res.json(email);
    } catch (error) {
      console.error("Error fetching email:", error);
      res.status(500).json({ error: "Failed to fetch email" });
    }
  });

  // Recipients
  app.get("/api/recipients", async (req, res) => {
    try {
      const recipients = await storage.getRecipients();
      res.json(recipients);
    } catch (error) {
      console.error("Error fetching recipients:", error);
      res.status(500).json({ error: "Failed to fetch recipients" });
    }
  });

  app.post("/api/recipients", async (req, res) => {
    try {
      const { email, name } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }

      const existingRecipient = await storage.getRecipientByEmail(email);
      if (existingRecipient) {
        return res.status(409).json({ error: "Recipient already exists" });
      }

      const recipient = await storage.createRecipient({ email, name });
      res.json(recipient);
    } catch (error) {
      console.error("Error creating recipient:", error);
      res.status(500).json({ error: "Failed to create recipient" });
    }
  });

  // Email templates
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getEmailTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching templates:", error);
      res.status(500).json({ error: "Failed to fetch templates" });
    }
  });

  app.post("/api/templates", async (req, res) => {
    try {
      const { name, subject, content } = req.body;
      
      if (!name || !subject || !content) {
        return res.status(400).json({ error: "Name, subject, and content are required" });
      }

      const template = await storage.createEmailTemplate({
        name,
        subject,
        content,
      });
      res.json(template);
    } catch (error) {
      console.error("Error creating template:", error);
      res.status(500).json({ error: "Failed to create template" });
    }
  });

  // Postal webhook endpoint
  app.post("/api/webhooks/postal", async (req, res) => {
    try {
      console.log("Webhook received:", JSON.stringify(req.body, null, 2));
      const event = req.body;
      
      if (!event.payload?.message_id) {
        console.log("Invalid webhook payload - missing message_id");
        return res.status(400).json({ error: "Invalid webhook payload" });
      }

      console.log("Processing webhook for message:", event.payload.message_id);
      const processedEvent = postalApi.processWebhookEvent(event);
      
      // Update email status
      const updates: any = {
        status: processedEvent.status,
      };

      if (processedEvent.bounceType) {
        updates.bounceType = processedEvent.bounceType;
      }

      if (processedEvent.status === 'delivered') {
        updates.deliveredAt = processedEvent.timestamp;
      }

      console.log("Updating email with:", updates);
      const result = await storage.updateEmailByPostalId(processedEvent.messageId, updates);
      console.log("Update result:", result);

      res.json({ success: true });
    } catch (error) {
      console.error("Error processing webhook:", error);
      res.status(500).json({ error: "Failed to process webhook" });
    }
  });

  // Manual status check for an email
  app.post("/api/emails/:id/check-status", async (req, res) => {
    try {
      const emailId = parseInt(req.params.id);
      const email = await storage.getEmail(emailId);
      
      if (!email || !email.postalMessageId) {
        return res.status(404).json({ error: "Email not found" });
      }

      const details = await postalApi.getMessageDetails(email.postalMessageId);
      const deliveries = await postalApi.getMessageDeliveries(email.postalMessageId);

      // Update email status based on Postal response
      // This is a simplified implementation - you might want more sophisticated status mapping
      if (deliveries && deliveries.length > 0) {
        const latestDelivery = deliveries[deliveries.length - 1];
        const updates: any = {};

        if (latestDelivery.status === 'Delivered') {
          updates.status = 'delivered';
          updates.deliveredAt = new Date(latestDelivery.timestamp);
        } else if (latestDelivery.status === 'Bounced') {
          updates.status = 'bounced';
          updates.bounceType = latestDelivery.bounce_type || 'unknown';
        }

        if (Object.keys(updates).length > 0) {
          await storage.updateEmail(emailId, updates);
        }
      }

      res.json({
        details,
        deliveries,
      });
    } catch (error) {
      console.error("Error checking email status:", error);
      res.status(500).json({ error: "Failed to check email status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
