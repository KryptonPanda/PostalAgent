import { 
  users, recipients, emailTemplates, emails, emailStats,
  type User, type InsertUser,
  type Recipient, type InsertRecipient,
  type EmailTemplate, type InsertEmailTemplate,
  type Email, type InsertEmail,
  type EmailStats
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Recipient methods
  getRecipients(): Promise<Recipient[]>;
  getRecipient(id: number): Promise<Recipient | undefined>;
  getRecipientByEmail(email: string): Promise<Recipient | undefined>;
  createRecipient(recipient: InsertRecipient): Promise<Recipient>;
  updateRecipient(id: number, updates: Partial<Recipient>): Promise<Recipient | undefined>;

  // Email template methods
  getEmailTemplates(): Promise<EmailTemplate[]>;
  getEmailTemplate(id: number): Promise<EmailTemplate | undefined>;
  createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate>;
  updateEmailTemplate(id: number, updates: Partial<EmailTemplate>): Promise<EmailTemplate | undefined>;

  // Email methods
  getEmails(limit?: number): Promise<Email[]>;
  getEmail(id: number): Promise<Email | undefined>;
  getEmailByPostalId(postalMessageId: string): Promise<Email | undefined>;
  createEmail(email: InsertEmail): Promise<Email>;
  updateEmail(id: number, updates: Partial<Email>): Promise<Email | undefined>;
  updateEmailByPostalId(postalMessageId: string, updates: Partial<Email>): Promise<Email | undefined>;

  // Analytics methods
  getDashboardStats(): Promise<{
    totalSent: number;
    totalDelivered: number;
    totalBounced: number;
    totalSpam: number;
    deliveryRate: number;
    bounceRate: number;
    spamRate: number;
  }>;
  getEmailStatsByDateRange(startDate: Date, endDate: Date): Promise<EmailStats[]>;
  getDeliveryTrends(days: number): Promise<any[]>;
  getStatusDistribution(): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Recipient methods
  async getRecipients(): Promise<Recipient[]> {
    return await db.select().from(recipients).orderBy(desc(recipients.createdAt));
  }

  async getRecipient(id: number): Promise<Recipient | undefined> {
    const [recipient] = await db.select().from(recipients).where(eq(recipients.id, id));
    return recipient || undefined;
  }

  async getRecipientByEmail(email: string): Promise<Recipient | undefined> {
    const [recipient] = await db.select().from(recipients).where(eq(recipients.email, email));
    return recipient || undefined;
  }

  async createRecipient(recipient: InsertRecipient): Promise<Recipient> {
    const [newRecipient] = await db
      .insert(recipients)
      .values(recipient)
      .returning();
    return newRecipient;
  }

  async updateRecipient(id: number, updates: Partial<Recipient>): Promise<Recipient | undefined> {
    const [updated] = await db
      .update(recipients)
      .set(updates)
      .where(eq(recipients.id, id))
      .returning();
    return updated || undefined;
  }

  // Email template methods
  async getEmailTemplates(): Promise<EmailTemplate[]> {
    return await db.select().from(emailTemplates).where(eq(emailTemplates.isActive, true)).orderBy(desc(emailTemplates.createdAt));
  }

  async getEmailTemplate(id: number): Promise<EmailTemplate | undefined> {
    const [template] = await db.select().from(emailTemplates).where(eq(emailTemplates.id, id));
    return template || undefined;
  }

  async createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate> {
    const [newTemplate] = await db
      .insert(emailTemplates)
      .values(template)
      .returning();
    return newTemplate;
  }

  async updateEmailTemplate(id: number, updates: Partial<EmailTemplate>): Promise<EmailTemplate | undefined> {
    const [updated] = await db
      .update(emailTemplates)
      .set(updates)
      .where(eq(emailTemplates.id, id))
      .returning();
    return updated || undefined;
  }

  // Email methods
  async getEmails(limit: number = 50): Promise<Email[]> {
    return await db.select().from(emails).orderBy(desc(emails.createdAt)).limit(limit);
  }

  async getEmail(id: number): Promise<Email | undefined> {
    const [email] = await db.select().from(emails).where(eq(emails.id, id));
    return email || undefined;
  }

  async getEmailByPostalId(postalMessageId: string): Promise<Email | undefined> {
    const [email] = await db.select().from(emails).where(eq(emails.postalMessageId, postalMessageId));
    return email || undefined;
  }

  async createEmail(email: InsertEmail): Promise<Email> {
    const [newEmail] = await db
      .insert(emails)
      .values(email)
      .returning();
    return newEmail;
  }

  async updateEmail(id: number, updates: Partial<Email>): Promise<Email | undefined> {
    const [updated] = await db
      .update(emails)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(emails.id, id))
      .returning();
    return updated || undefined;
  }

  async updateEmailByPostalId(postalMessageId: string, updates: Partial<Email>): Promise<Email | undefined> {
    const [updated] = await db
      .update(emails)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(emails.postalMessageId, postalMessageId))
      .returning();
    return updated || undefined;
  }

  // Analytics methods
  async getDashboardStats(): Promise<{
    totalSent: number;
    totalDelivered: number;
    totalBounced: number;
    totalSpam: number;
    deliveryRate: number;
    bounceRate: number;
    spamRate: number;
  }> {
    const stats = await db
      .select({
        totalSent: sql<number>`count(*)`,
        totalDelivered: sql<number>`count(*) filter (where status = 'delivered')`,
        totalBounced: sql<number>`count(*) filter (where status = 'bounced')`,
        totalSpam: sql<number>`count(*) filter (where status = 'spam')`,
      })
      .from(emails);

    const result = stats[0];
    const deliveryRate = result.totalSent > 0 ? (result.totalDelivered / result.totalSent) * 100 : 0;
    const bounceRate = result.totalSent > 0 ? (result.totalBounced / result.totalSent) * 100 : 0;
    const spamRate = result.totalSent > 0 ? (result.totalSpam / result.totalSent) * 100 : 0;

    return {
      ...result,
      deliveryRate: Math.round(deliveryRate * 100) / 100,
      bounceRate: Math.round(bounceRate * 100) / 100,
      spamRate: Math.round(spamRate * 100) / 100,
    };
  }

  async getEmailStatsByDateRange(startDate: Date, endDate: Date): Promise<EmailStats[]> {
    return await db
      .select()
      .from(emailStats)
      .where(and(gte(emailStats.date, startDate), lte(emailStats.date, endDate)))
      .orderBy(emailStats.date);
  }

  async getDeliveryTrends(days: number): Promise<any[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const trends = await db
      .select({
        date: sql<string>`date_trunc('day', created_at)`,
        delivered: sql<number>`count(*) filter (where status = 'delivered')`,
        bounced: sql<number>`count(*) filter (where status = 'bounced')`,
        spam: sql<number>`count(*) filter (where status = 'spam')`,
        total: sql<number>`count(*)`,
      })
      .from(emails)
      .where(gte(emails.createdAt, startDate))
      .groupBy(sql`date_trunc('day', created_at)`)
      .orderBy(sql`date_trunc('day', created_at)`);

    return trends;
  }

  async getStatusDistribution(): Promise<any[]> {
    const distribution = await db
      .select({
        status: emails.status,
        count: sql<number>`count(*)`,
      })
      .from(emails)
      .groupBy(emails.status);

    return distribution;
  }
}

export const storage = new DatabaseStorage();
