import { pgTable, text, serial, integer, boolean, timestamp, decimal, json } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const recipients = pgTable("recipients", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailTemplates = pgTable("email_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emails = pgTable("emails", {
  id: serial("id").primaryKey(),
  postalMessageId: text("postal_message_id").unique(),
  fromEmail: text("from_email").notNull(),
  toEmail: text("to_email").notNull(),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  status: text("status").notNull().default("pending"), // pending, sent, delivered, bounced, spam, failed
  bounceType: text("bounce_type"), // soft, hard
  deliveredAt: timestamp("delivered_at"),
  openedAt: timestamp("opened_at"),
  clickedAt: timestamp("clicked_at"),
  unsubscribedAt: timestamp("unsubscribed_at"),
  spamReportedAt: timestamp("spam_reported_at"),
  errorMessage: text("error_message"),
  recipientId: integer("recipient_id").references(() => recipients.id),
  templateId: integer("template_id").references(() => emailTemplates.id),
  metadata: json("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const emailStats = pgTable("email_stats", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  totalSent: integer("total_sent").default(0),
  totalDelivered: integer("total_delivered").default(0),
  totalBounced: integer("total_bounced").default(0),
  totalSpam: integer("total_spam").default(0),
  totalOpened: integer("total_opened").default(0),
  totalClicked: integer("total_clicked").default(0),
  totalUnsubscribed: integer("total_unsubscribed").default(0),
  softBounces: integer("soft_bounces").default(0),
  hardBounces: integer("hard_bounces").default(0),
  deliveryRate: decimal("delivery_rate", { precision: 5, scale: 2 }),
  bounceRate: decimal("bounce_rate", { precision: 5, scale: 2 }),
  spamRate: decimal("spam_rate", { precision: 5, scale: 2 }),
  openRate: decimal("open_rate", { precision: 5, scale: 2 }),
  clickRate: decimal("click_rate", { precision: 5, scale: 2 }),
});

// Relations
export const recipientsRelations = relations(recipients, ({ many }) => ({
  emails: many(emails),
}));

export const emailTemplatesRelations = relations(emailTemplates, ({ many }) => ({
  emails: many(emails),
}));

export const emailsRelations = relations(emails, ({ one }) => ({
  recipient: one(recipients, {
    fields: [emails.recipientId],
    references: [recipients.id],
  }),
  template: one(emailTemplates, {
    fields: [emails.templateId],
    references: [emailTemplates.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertRecipientSchema = createInsertSchema(recipients).omit({
  id: true,
  createdAt: true,
});

export const insertEmailTemplateSchema = createInsertSchema(emailTemplates).omit({
  id: true,
  createdAt: true,
});

export const insertEmailSchema = createInsertSchema(emails).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const sendEmailSchema = z.object({
  fromEmail: z.string().email(),
  toEmail: z.string().email(),
  subject: z.string().min(1),
  content: z.string().min(1),
  recipientId: z.number().optional(),
  templateId: z.number().optional(),
  trackDelivery: z.boolean().default(true),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Recipient = typeof recipients.$inferSelect;
export type InsertRecipient = z.infer<typeof insertRecipientSchema>;

export type EmailTemplate = typeof emailTemplates.$inferSelect;
export type InsertEmailTemplate = z.infer<typeof insertEmailTemplateSchema>;

export type Email = typeof emails.$inferSelect;
export type InsertEmail = z.infer<typeof insertEmailSchema>;
export type SendEmail = z.infer<typeof sendEmailSchema>;

export type EmailStats = typeof emailStats.$inferSelect;
